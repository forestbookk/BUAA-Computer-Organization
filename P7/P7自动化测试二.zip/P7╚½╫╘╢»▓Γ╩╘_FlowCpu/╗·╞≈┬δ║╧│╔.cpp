#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
char IM[5000][32];
int main()
{
	FILE* in;
	in = fopen("machine.txt", "r");
	int i = 0;
	while ((fscanf(in, "%s", IM[i])) != EOF)
	{
		i++;
	}
	fclose(in);
	FILE* handler;
	handler = fopen("handler.txt", "r");
	int j = 1120;
	while ((fscanf(handler, "%s", IM[j])) != EOF)
	{
		j++;
	}
	fclose(handler);
	freopen("code.txt", "w", stdout);
	for (int i = 0;i <= 5000;i++)
	{
		if (IM[i][0] == 0)
		{
			printf("00000000\n");
		}
		else
		{
			printf("%s\n", IM[i]);
		}
	}
}
