import difflib
import os
import re
import sys
import time

import filestools
from filediff.diff import file_diff_compare
p_road = "C:\\Users\\Unicorn\\Desktop\\P7\\P7exp\\FlowCpu"
d_road = "C:\\Users\\Unicorn\\Desktop\\P7\\P7exp\\P7jbw"
run_time = "100us"
xilinx_path = "G:\\ISE\\14.7\\ISE_DS\\ISE"
dir_name = 'C:\\Users\\Unicorn\\Desktop\\P7\\P7exp\\P7全自动测试_对拍\\测试记录\\mars文件\\'
dir_name_3 = 'C:\\Users\\Unicorn\\Desktop\\P7\\P7exp\\P7全自动测试_对拍\\测试记录\\机器码文件\\'
dir_name_1 = 'C:\\Users\\Unicorn\\Desktop\\P7\\P7exp\\P7全自动测试_对拍\\测试记录\\比较文件\\'
dir_name_2 = 'C:\\Users\\Unicorn\\Desktop\\P7\\P7exp\\P7全自动测试_对拍\\测试记录\\'
error = []


def generate(test_order):
    # print("生成指令中" + '\n')
    command = "C语言.exe"
    os.system(command)
    f_1 = open('test.asm', "r")
    list_temp = f_1.readlines()
    f_2 = open(dir_name + 'test'+str(test_order)+'.asm', "w")
    f_2.writelines(list_temp)
    f_1.close()
    f_2.close()


def run_mar(test_order):
    # print("生成机器码中" + '\n')
    os.system("java -jar Mars.jar mc LargeText a dump .text HexText machine.txt nc test.asm")
    os.system("java -jar Mars.jar mc LargeText a dump 0x00004180-0x00006000 HexText handler.txt nc test.asm")
    os.system("机器码合成.exe")
    f_1 = open('code.txt', "r")
    list_temp = f_1.readlines()
    f_2 = open(dir_name_3 + 'test'+str(test_order)+'.txt', "w")
    f_2.writelines(list_temp)
    f_1.close()
    f_2.close()
    # print("生成标准答案中" + '\n')
    os.system("java -jar Mars.jar mc LargeText nc db lg ex me 65536 test.asm > mar.txt")
# 循环结尾 os.system("java -jar Mars_perfect.jar mc CompactDataAtZero nc db me 65536  test.asm > mar.txt")
# 延迟槽 os.system("java -jar Mars_perfect.jar mc CompactDataAtZero nc db test.asm > mar.txt")

def run_ise_p():
    # print("运行ise中" + '\n')
    file_list = []
    for i, j, k in os.walk(p_road):
        for file in k:
            if file.endswith(".v"):
                file_list.append(file)
    with open(p_road + "\\mips.prj", "w") as prj:
        for i in range(len(file_list)):
            prj.write("Verilog work \"" + p_road + "\\" + file_list[i] + "\"\n")
    with open(p_road + "\mips.tcl", "w") as tcl:
        tcl.write("run " + run_time +";\nexit")
    prj.close()
    tcl.close()
    os.environ["XILINX"] = xilinx_path
    os.system(xilinx_path + "\\bin\\nt64\\fuse -nodebug -prj " + p_road + "\\mips.prj -o mips.exe mips_txt > compile_log.txt")
    os.system("mips.exe -nolog -tclbatch " + p_road + "\\mips.tcl> raw_out_p.txt")


def run_ise_d():
    # print("运行ise中" + '\n')
    file_list = []
    for i, j, k in os.walk(d_road):
        for file in k:
            if file.endswith(".v"):
                file_list.append(file)
    with open(d_road + "\\mips.prj", "w") as prj:
        for i in range(len(file_list)):
            prj.write("Verilog work \"" + d_road + "\\" + file_list[i] + "\"\n")
    with open(d_road + "\mips.tcl", "w") as tcl:
        tcl.write("run " + run_time +";\nexit")
    prj.close()
    tcl.close()
    os.environ["XILINX"] = xilinx_path
    os.system(xilinx_path + "\\bin\\nt64\\fuse -nodebug -prj " + d_road + "\\mips.prj -o mips.exe mips_txt > compile_log.txt")
    os.system("mips.exe -nolog -tclbatch " + d_road + "\\mips.tcl> raw_out_d.txt")


def process_p():
    # print("转换ise答案中" + '\n')
    myfriendmem = open("raw_out_p.txt", encoding="utf-8").read()
    j = 0
    while myfriendmem[j] != '@':
        j = j + 1
    mymem = ''
    for i in range(j, len(myfriendmem)):
        mymem = mymem + myfriendmem[i]
    with open("verilog_p.txt", "w", encoding="utf-8") as file:
        file.write(mymem)



def process_d():
    # print("转换ise答案中" + '\n')
    myfriendmem = open("raw_out_d.txt", encoding="utf-8").read()
    j = 0
    while myfriendmem[j] != '@':
        j = j + 1
    mymem = ''
    for i in range(j, len(myfriendmem)):
        mymem = mymem + myfriendmem[i]
    with open("verilog_d.txt", "w", encoding="utf-8") as file:
        file.write(mymem)



def copy_file(name, target_road):
    f_1 = open(name, "r")
    list_temp = f_1.readlines()
    f_2 = open(target_road + "\\" + name, "w")
    f_2.writelines(list_temp)
    f_1.close()
    f_2.close()


def file_cmp(test_order):
    co = open(dir_name_2 + 'result.txt', mode='a', encoding='utf-8')
    co.write("第"+str(test_order)+"次比较结果:"+'\n')
    print("第"+str(test_order)+"次比较结果:")
    with open("verilog_p.txt", "r") as out_1:
        out_std = out_1.readlines()
        # out_std.remove('\n')
    with open("verilog_d.txt", "r+") as out_2:
        out_test = out_2.readlines()
    with open(".\\log.txt".format(test_order), "w") as log:
        flag = 0
        if len(out_std) > len(out_test):
            flag = 1;
        else:
            for i in range(len(out_std)):
                if out_std[i] != out_test[i]:
                    flag = 1;
                    log.write("error in line {}\n expected output is {}\nyour outout is {}\n\n".format(i, out_std[i], out_test[i]))
        if flag:
            print("Wrong Answer!")
            co.write("Wrong Answer!"+'\n')
            # os.makedirs(".\\test_log_file\\log_{}\\".format(i))
            # copy_file("log.txt", ".\\test_log_file\\log_{}".format(i))
            # copy_file("test.asm", ".\\test_log_file\\log_{}".format(i))
            # copy_file("mar.txt", ".\\test_log_file\\log_{}".format(i))
            # copy_file("verilog.txt", ".\\test_log_file\\log_{}".format(i))
        else:
            print("Accepted!")
            co.write("Accepted!"+'\n')
    co.close()

def read_file(filename):
    try:
        with open(filename, 'r') as f:
            return f.readlines()
    except IOError:
        print("ERROR: 没有找到文件:%s或读取文件失败！" % filename)
        sys.exit(1)


def compare_file(file1, file2, out_file):
    file1_content = read_file(file1)
    file2_content = read_file(file2)
    d = difflib.HtmlDiff()
    result = d.make_file(file1_content, file2_content)
    fb = open(dir_name_1 + out_file, mode='w', encoding='utf-8')
    fb.write(result)
    # with open(dir_name + out_file, 'w') as f:
    #     f.writelines(result)

def zip(test_order):
    os.system("\"C:\\Program Files (x86)\\360\\360zip\\360zip.exe\" -ar code.txt C:\\Users\\Unicorn\\Desktop\\P7\\P7exp\\P7全自动测试_对拍\\压缩文件\\P7_Q"+str(test_order)+".zip")


print("输入测试次数:")
test_times =int(input())
co = open(dir_name_2 + 'result.txt', mode='w', encoding='utf-8')
co.write("测试次数:"+str(test_times)+'\n')
co.close()
for i in range(test_times):
    generate(i+1)
    run_mar(i+1)
    run_ise_p()
    run_ise_d()
    process_p()
    process_d()
    # zip(i+1)
    # print("比较答案中" + '\n')
    compare_file(r'verilog_p.txt', r'verilog_d.txt', 'result'+str(i+1)+'.html')
    file_cmp(i+1)
    time.sleep(3)
print("Done!" + '\n')
