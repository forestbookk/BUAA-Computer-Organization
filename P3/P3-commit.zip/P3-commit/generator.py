import random
import sys
label = [0]*3200
labelIndex = 0
#0.open test.asm
sys.stdout = open("D:\BUAA\practice\logism\cpu_test\\test.asm", "w")

#1.instruction
def add(rd, rs, rt):
    if rd == 0:
        return
    print("add $"+str(rd)+",$"+str(rs)+",$"+str(rt))
    return
def sub(rd, rs, rt):
    if rd == 0: 
        return
    print("sub $"+str(rd)+",$"+str(rs)+",$"+str(rt))
    return
def ori(rt, rs, imm):
    if rt == 0:
        return
    print("ori $"+str(rt)+",$"+str(rs)+","+str(imm))
    return
def lw(rt, base):
    if rt == 0:
        return
    offset = random.randint(0,40) * 4
    print("lw $"+str(rt)+","+str(offset)+"($"+str(base)+")")
    return
def sw(base, rt):
    offset = random.randint(0,40) * 4
    print("sw $"+str(rt)+","+str(offset)+"($"+str(base)+")")
    return
def lui(rt):
    if rt == 0:
        return
    imm = random.randint(0,40) * 4
    print("lui $"+str(rt)+","+str(imm))
    return
def beq(rs, rt):       
    jumpLabelIndex = random.randint(1, labelIndex)
    while(label[jumpLabelIndex]):
        jumpLabelIndex = random.randint(1, labelIndex) #防止跳进已经走过的地方形成循环
    print("beq $"+str(rt)+",$"+str(rs)+","+"Jump"+str(jumpLabelIndex))
    print("nop\n")
    return

#2.generate instruction
def generate(op, rs, rt, rd):
    match op:
        case 0:
            print("nop")    
        case 1:
            sub(rd, rs, rt)
        case 2:
            imm = random.randint(0, 456)
            ori(rt, rs, imm)
        case 3:
            lw(rt, rs)
        case 4:
            sw(rs, rt)        
        case 5:
            lui(rt)  
        case 6:
            add(rd, rs, rt)
        case 7:
            beq(rs, rt) 
        case _:
            return    
    return

#3.main logic
for index in range(0,31):
    imm = random.randint(3, 12)
    ori(index, 0, imm)

for i in range(0, 512):
    op = random.randint(0,7)  
    if op <= 6:
        generate(op, random.randint(0,31), random.randint(0,31), random.randint(0,31))
    elif labelIndex > 0:
        isJump = 0
        for index in range(1,labelIndex):
            if label[index] == 0:
                isJump = 1
        if isJump == 1:
            generate(op, random.randint(0,31), random.randint(0,31), random.randint(0,31))   

    isLabel = random.randint(0,1)
    if random.randint(18,35) % random.randint(7,11) == 0 and isLabel == 1:
        labelIndex = labelIndex + 1
        print("\nJump"+ str(labelIndex)+":")